# Racha dos Clandestinos — Android

Projeto Android que empacota o sistema HTML/JavaScript em um APK.

## Como gerar o APK pelo GitHub

1. Envie estes arquivos para o repositório.
2. Vá em Actions.
3. Execute `Build APK`.
4. Baixe o artefato `RachaDosClandestinos-debug`.
5. Dentro dele estará `app-debug.apk`.

O aplicativo usa armazenamento local do WebView para manter os jogadores, gols e assistências no aparelho.
